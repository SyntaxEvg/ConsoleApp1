# Скрипт для создания структуры папок Views

# Функция для создания папки и файлов
function Create-Structure {
    param(
        [string]$BasePath,
        [hashtable]$Structure
    )
    
    foreach ($item in $Structure.GetEnumerator()) {
        $fullPath = Join-Path $BasePath $item.Key
        
        if ($item.Value -is [hashtable]) {
            # Это папка с вложенным содержимым
            #Write-Host "Создаю папку: $fullPath" -ForegroundColor Green
            New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
            Create-Structure -BasePath $fullPath -Structure $item.Value
        }
        else {
            # Это файл
            #Write-Host "Создаю файл: $fullPath" -ForegroundColor Yellow
            New-Item -ItemType File -Path $fullPath -Force | Out-Null
        }
    }
}

# Определяем структуру папок
$folderStructure = @{
    "Areas" = @{
        "Admin" = @{
            "Views" = @{
                "AccessToken" = @{
                    "Create.cshtml" = $null
                    "Edit.cshtml" = $null
                    "Index.cshtml" = $null
                }
                "ApiKey" = @{
                    "Create.cshtml" = $null
                    "Index.cshtml" = $null
                }
                "Client" = @{
                    "Create.cshtml" = $null
                    "Edit.cshtml" = $null
                    "Index.cshtml" = $null
                }
                "Hopex" = @{
                    "Index.cshtml" = $null
                }
                "OpenId" = @{
                    "Edit.cshtml" = $null
                    "Index.cshtml" = $null
                }
                "SAML2" = @{
                    "Edit.cshtml" = $null
                    "Index.cshtml" = $null
                }
                "Shared" = @{
                    "Error.cshtml" = $null
                    "_AdminLayout.cshtml" = $null
                    "_ValidationSummary.cshtml" = $null
                }
                "Windows" = @{
                    "Index.cshtml" = $null
                }
                "_ViewImports.cshtml" = $null
                "_ViewStart.cshtml" = $null
            }
        }
    }
    "Views" = @{
        "Account" = @{
            "AccessDenied.cshtml" = $null
            "ChangePassword.cshtml" = $null
            "Error.cshtml" = $null
            "LoggedOut.cshtml" = $null
            "Login.cshtml" = $null
            "Logout.cshtml" = $null
            "Mapping.cshtml" = $null
            "TimedOut.cshtml" = $null
        }
        "Password" = @{
            "LostPassword.cshtml" = $null
        }
        "Shared" = @{
            "_Layout.cshtml" = $null
            "_Layout.account.cshtml" = $null
            "_ValidationSummary.cshtml" = $null
        }
        "_ViewImports.cshtml" = $null
        "_ViewStart.cshtml" = $null
    }
}

# Текущая директория (можно изменить на нужный путь)
$baseDirectory = Get-Location

#Write-Host "Начинаю создание структуры папок..." -ForegroundColor Cyan
#Write-Host "Базовый путь: $baseDirectory" -ForegroundColor Cyan

# Создаем структуру
Create-Structure -BasePath $baseDirectory -Structure $folderStructure

#Write-Host "Структура папок успешно создана!" -ForegroundColor Green
#Write-Host "Проверьте созданные папки и файлы." -ForegroundColor Green

# Показать итоговую структуру
##Write-Host "Созданная структура:" -ForegroundColor Cyan
Get-ChildItem -Path $baseDirectory -Recurse -Directory | ForEach-Object {
    $relativePath = $_.FullName.Replace($baseDirectory, "").TrimStart("\")
    #Write-Host "📁 $relativePath" -ForegroundColor Blue
}

Get-ChildItem -Path $baseDirectory -Recurse -File | ForEach-Object {
    $relativePath = $_.FullName.Replace($baseDirectory, "").TrimStart("\")
    #Write-Host "   📄 $relativePath" -ForegroundColor Gray
}