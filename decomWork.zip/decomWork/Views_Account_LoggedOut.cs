﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using HAS.Server.SiteModule.Razor;
using Mega.Has.Modules.UAS.ViewModels;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Mvc.Razor.Internal;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.TagHelpers;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.Hosting;
using Microsoft.AspNetCore.Razor.Runtime.TagHelpers;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace AspNetCoreGeneratedDocument
{
	// Token: 0x02000045 RID: 69
	[RazorSourceChecksum("SHA256", "b45dae28e1e1424999910ea5c60066feec960575993268b4d4ec8e3cdc068f6d", "/Views/Account/LoggedOut.cshtml")]
	[RazorSourceChecksum("SHA256", "c68eee8ac38defce2d4a072bcc9cf01bbc2882ac7d678ff69084a79c4d2ae0a8", "/Views/_ViewImports.cshtml")]
	[RazorCompiledItemMetadata("Identifier", "/Views/Account/LoggedOut.cshtml")]
	[CreateNewOnMetadataUpdate]
	internal sealed class Views_Account_LoggedOut : BaseRazorPage<LoggedOutViewModel>
	{
		// Token: 0x17000166 RID: 358
		// (get) Token: 0x06000302 RID: 770 RVA: 0x0000C486 File Offset: 0x0000A686
		private TagHelperScopeManager __tagHelperScopeManager
		{
			get
			{
				if (this.__backed__tagHelperScopeManager == null)
				{
					this.__backed__tagHelperScopeManager = new TagHelperScopeManager(new Action<HtmlEncoder>(base.StartTagHelperWritingScope), new Func<TagHelperContent>(base.EndTagHelperWritingScope));
				}
				return this.__backed__tagHelperScopeManager;
			}
		}

		// Token: 0x06000303 RID: 771 RVA: 0x0000C4BC File Offset: 0x0000A6BC
		public override Task ExecuteAsync()
		{
			Views_Account_LoggedOut.ExecuteAsync_StateMachine_10 executeAsync_d__;
			executeAsync_d__.taskBuilder = AsyncTaskMethodBuilder.Create();
			executeAsync_d__.capturedThis = this;
			executeAsync_d__.stateMachineState = -1;
			executeAsync_d__.taskBuilder.Start<Views_Account_LoggedOut.ExecuteAsync_StateMachine_10>(ref executeAsync_d__);
			return executeAsync_d__.taskBuilder.Task;
		}

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x06000304 RID: 772 RVA: 0x0000C4FF File Offset: 0x0000A6FF
		// (set) Token: 0x06000305 RID: 773 RVA: 0x0000C507 File Offset: 0x0000A707
		[RazorInject]
		public IModelExpressionProvider ModelExpressionProvider { get; private set; }

		// Token: 0x17000168 RID: 360
		// (get) Token: 0x06000306 RID: 774 RVA: 0x0000C510 File Offset: 0x0000A710
		// (set) Token: 0x06000307 RID: 775 RVA: 0x0000C518 File Offset: 0x0000A718
		[RazorInject]
		public IUrlHelper Url { get; private set; }

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x06000308 RID: 776 RVA: 0x0000C521 File Offset: 0x0000A721
		// (set) Token: 0x06000309 RID: 777 RVA: 0x0000C529 File Offset: 0x0000A729
		[RazorInject]
		public IViewComponentHelper Component { get; private set; }

		// Token: 0x1700016A RID: 362
		// (get) Token: 0x0600030A RID: 778 RVA: 0x0000C532 File Offset: 0x0000A732
		// (set) Token: 0x0600030B RID: 779 RVA: 0x0000C53A File Offset: 0x0000A73A
		[RazorInject]
		public IJsonHelper Json { get; private set; }

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x0600030C RID: 780 RVA: 0x0000C543 File Offset: 0x0000A743
		// (set) Token: 0x0600030D RID: 781 RVA: 0x0000C54B File Offset: 0x0000A74B
		[RazorInject]
		public IHtmlHelper<LoggedOutViewModel> Html { get; private set; }

		// Token: 0x06000310 RID: 784 RVA: 0x0000C5C0 File Offset: 0x0000A7C0
		[CompilerGenerated]
		private Task ExecuteAsync_Lambda_10_1()
		{
			Views_Account_LoggedOut.ExecuteAsync_Lambda_10_1_StateMachine ExecuteAsync_Lambda_10_1_StateMachine;
			ExecuteAsync_Lambda_10_1_StateMachine.taskBuilder = AsyncTaskMethodBuilder.Create();
			ExecuteAsync_Lambda_10_1_StateMachine.capturedThis = this;
			ExecuteAsync_Lambda_10_1_StateMachine.stateMachineState = -1;
			ExecuteAsync_Lambda_10_1_StateMachine.taskBuilder.Start<Views_Account_LoggedOut.ExecuteAsync_Lambda_10_1_StateMachine>(ref ExecuteAsync_Lambda_10_1_StateMachine);
			return ExecuteAsync_Lambda_10_1_StateMachine.taskBuilder.Task;
		}

		// Token: 0x040002C7 RID: 711
		private static readonly TagHelperAttribute __tagHelperAttribute_0 = new TagHelperAttribute("src", "/_customs/has.uas/images/logo-H.png", HtmlAttributeValueStyle.DoubleQuotes);

		// Token: 0x040002C8 RID: 712
		private static readonly TagHelperAttribute __tagHelperAttribute_1 = new TagHelperAttribute("class", new HtmlString("titleimg"), HtmlAttributeValueStyle.DoubleQuotes);

		// Token: 0x040002C9 RID: 713
		private static readonly TagHelperAttribute __tagHelperAttribute_2 = new TagHelperAttribute("alt", new HtmlString("HOPEX"), HtmlAttributeValueStyle.DoubleQuotes);

		// Token: 0x040002CA RID: 714
		private TagHelperExecutionContext __tagHelperExecutionContext;

		// Token: 0x040002CB RID: 715
		private TagHelperRunner __tagHelperRunner = new TagHelperRunner();

		// Token: 0x040002CC RID: 716
		private string __tagHelperStringValueBuffer;

		// Token: 0x040002CD RID: 717
		private TagHelperScopeManager __backed__tagHelperScopeManager;

		// Token: 0x040002CE RID: 718
		private ImageTagHelper __Microsoft_AspNetCore_Mvc_TagHelpers_ImageTagHelper;

		// Token: 0x02000159 RID: 345
		[CompilerGenerated]
		[StructLayout(LayoutKind.Auto)]
		private struct ExecuteAsync_Lambda_10_1_StateMachine : IAsyncStateMachine
		{
			// Token: 0x06000A67 RID: 2663 RVA: 0x0004680C File Offset: 0x00044A0C
			void IAsyncStateMachine.MoveNext()
			{
				int num = this.stateMachineState;
				Views_Account_LoggedOut views_Account_LoggedOut = this.capturedThis;
				try
				{
					views_Account_LoggedOut.WriteLiteral("\r\n\r\n");
					if (views_Account_LoggedOut.Model.AutomaticRedirectAfterSignOut)
					{
						views_Account_LoggedOut.WriteLiteral("        <script src=\"/uas/js/signout-redirect.js\"></script>\r\n");
					}
				}
				catch (Exception ex)
				{
					this.stateMachineState = -2;
					this.taskBuilder.SetException(ex);
					return;
				}
				this.stateMachineState = -2;
				this.taskBuilder.SetResult();
			}

			// Token: 0x06000A68 RID: 2664 RVA: 0x00046888 File Offset: 0x00044A88
			[DebuggerHidden]
			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
			{
				this.taskBuilder.SetStateMachine(stateMachine);
			}

			// Token: 0x04000820 RID: 2080
			public int stateMachineState;

			// Token: 0x04000821 RID: 2081
			public AsyncTaskMethodBuilder taskBuilder;

			// Token: 0x04000822 RID: 2082
			public Views_Account_LoggedOut capturedThis;
		}

		// Token: 0x0200015A RID: 346
		[CompilerGenerated]
		[Serializable]
		private sealed class CompilerGeneratedClass
		{
			// Token: 0x06000A6B RID: 2667 RVA: 0x000468AC File Offset: 0x00044AAC
			internal Task ExecuteAsync_Lambda_10_0()
			{
				Views_Account_LoggedOut.CompilerGeneratedClass.ExecuteAsync_Lambda_10_0_StateMachine ExecuteAsync_Lambda_10_0_StateMachine;
				ExecuteAsync_Lambda_10_0_StateMachine.taskBuilder = AsyncTaskMethodBuilder.Create();
				ExecuteAsync_Lambda_10_0_StateMachine.stateMachineState = -1;
				ExecuteAsync_Lambda_10_0_StateMachine.taskBuilder.Start<Views_Account_LoggedOut.CompilerGeneratedClass.ExecuteAsync_Lambda_10_0_StateMachine>(ref ExecuteAsync_Lambda_10_0_StateMachine);
				return ExecuteAsync_Lambda_10_0_StateMachine.taskBuilder.Task;
			}

			// Token: 0x04000823 RID: 2083
			public static readonly Views_Account_LoggedOut.CompilerGeneratedClass cachedDelegateHolder = new Views_Account_LoggedOut.CompilerGeneratedClass();

			// Token: 0x04000824 RID: 2084
			public static Func<Task> cachedDelegate_10_0;

			// Token: 0x0200032F RID: 815
			[StructLayout(LayoutKind.Auto)]
			private struct ExecuteAsync_Lambda_10_0_StateMachine : IAsyncStateMachine
			{
				// Token: 0x06000F6C RID: 3948 RVA: 0x00075CE8 File Offset: 0x00073EE8
				void IAsyncStateMachine.MoveNext()
				{
					int num = this.stateMachineState;
					try
					{
					}
					catch (Exception ex)
					{
						this.stateMachineState = -2;
						this.taskBuilder.SetException(ex);
						return;
					}
					this.stateMachineState = -2;
					this.taskBuilder.SetResult();
				}

				// Token: 0x06000F6D RID: 3949 RVA: 0x00075D38 File Offset: 0x00073F38
				[DebuggerHidden]
				void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
				{
					this.taskBuilder.SetStateMachine(stateMachine);
				}

				// Token: 0x04000F01 RID: 3841
				public int stateMachineState;

				// Token: 0x04000F02 RID: 3842
				public AsyncTaskMethodBuilder taskBuilder;
			}
		}

		// Token: 0x0200015B RID: 347
		[CompilerGenerated]
		[StructLayout(LayoutKind.Auto)]
		private struct ExecuteAsync_StateMachine_10 : IAsyncStateMachine
		{
			// Token: 0x06000A6C RID: 2668 RVA: 0x000468E8 File Offset: 0x00044AE8
			void IAsyncStateMachine.MoveNext()
			{
				int num = this.stateMachineState;
				Views_Account_LoggedOut views_Account_LoggedOut = this.capturedThis;
				try
				{
					TaskAwaiter awaiter;
					TaskAwaiter awaiter2;
					if (num != 0)
					{
						if (num == 1)
						{
							awaiter = this.awaiter_1;
							this.awaiter_1 = default(TaskAwaiter);
							this.stateMachineState = -1;
							goto IL_01E7;
						}
						views_Account_LoggedOut.WriteLiteral("\r\n");
						views_Account_LoggedOut.ViewData["signed-out"] = true;
						views_Account_LoggedOut.WriteLiteral("\r\n<div class=\"login\">\r\n    <div class=\"account-login border shadow rounded pt-3\">\r\n        <div class=\"text-center py-3 \">\r\n            ");
						views_Account_LoggedOut.__tagHelperExecutionContext = views_Account_LoggedOut.__tagHelperScopeManager.Begin("img", TagMode.SelfClosing, "b45dae28e1e1424999910ea5c60066feec960575993268b4d4ec8e3cdc068f6d5234", new Func<Task>(Views_Account_LoggedOut.CompilerGeneratedClass.cachedDelegateHolder.ExecuteAsync_Lambda_10_0));
						views_Account_LoggedOut.__Microsoft_AspNetCore_Mvc_TagHelpers_ImageTagHelper = views_Account_LoggedOut.CreateTagHelper<ImageTagHelper>();
						views_Account_LoggedOut.__tagHelperExecutionContext.Add(views_Account_LoggedOut.__Microsoft_AspNetCore_Mvc_TagHelpers_ImageTagHelper);
						views_Account_LoggedOut.__Microsoft_AspNetCore_Mvc_TagHelpers_ImageTagHelper.Src = (string)Views_Account_LoggedOut.__tagHelperAttribute_0.Value;
						views_Account_LoggedOut.__tagHelperExecutionContext.AddTagHelperAttribute(Views_Account_LoggedOut.__tagHelperAttribute_0);
						views_Account_LoggedOut.__tagHelperExecutionContext.AddHtmlAttribute(Views_Account_LoggedOut.__tagHelperAttribute_1);
						views_Account_LoggedOut.__tagHelperExecutionContext.AddHtmlAttribute(Views_Account_LoggedOut.__tagHelperAttribute_2);
						views_Account_LoggedOut.__Microsoft_AspNetCore_Mvc_TagHelpers_ImageTagHelper.AppendVersion = true;
						views_Account_LoggedOut.__tagHelperExecutionContext.AddTagHelperAttribute("asp-append-version", views_Account_LoggedOut.__Microsoft_AspNetCore_Mvc_TagHelpers_ImageTagHelper.AppendVersion, HtmlAttributeValueStyle.DoubleQuotes);
						awaiter2 = views_Account_LoggedOut.__tagHelperRunner.RunAsync(views_Account_LoggedOut.__tagHelperExecutionContext).GetAwaiter();
						if (!awaiter2.IsCompleted)
						{
							this.stateMachineState = 0;
							this.awaiter_1 = awaiter2;
							this.taskBuilder.AwaitUnsafeOnCompleted<TaskAwaiter, Views_Account_LoggedOut.ExecuteAsync_StateMachine_10>(ref awaiter2, ref this);
							return;
						}
					}
					else
					{
						awaiter2 = this.awaiter_1;
						this.awaiter_1 = default(TaskAwaiter);
						this.stateMachineState = -1;
					}
					awaiter2.GetResult();
					if (views_Account_LoggedOut.__tagHelperExecutionContext.Output.IsContentModified)
					{
						goto IL_01EE;
					}
					awaiter = views_Account_LoggedOut.__tagHelperExecutionContext.SetOutputContentAsync().GetAwaiter();
					if (!awaiter.IsCompleted)
					{
						this.stateMachineState = 1;
						this.awaiter_1 = awaiter;
						this.taskBuilder.AwaitUnsafeOnCompleted<TaskAwaiter, Views_Account_LoggedOut.ExecuteAsync_StateMachine_10>(ref awaiter, ref this);
						return;
					}
					IL_01E7:
					awaiter.GetResult();
					IL_01EE:
					views_Account_LoggedOut.Write(views_Account_LoggedOut.__tagHelperExecutionContext.Output);
					views_Account_LoggedOut.__tagHelperExecutionContext = views_Account_LoggedOut.__tagHelperScopeManager.End();
					views_Account_LoggedOut.WriteLiteral("\r\n        </div>\r\n        <h5 class=\"m-2\">");
					views_Account_LoggedOut.Write(views_Account_LoggedOut.T["Logout"]);
					views_Account_LoggedOut.WriteLiteral("</h5>\r\n        <div class=\"m-2 alert alert-success text-center\">");
					views_Account_LoggedOut.Write(views_Account_LoggedOut.T["You are now logged out"]);
					views_Account_LoggedOut.WriteLiteral("</div>\r\n        <div class=\"text-center\">\r\n");
					if (views_Account_LoggedOut.Model.PostLogoutRedirectUri != null)
					{
						views_Account_LoggedOut.WriteLiteral("                <div>\r\n                    Click <a class=\"PostLogoutRedirectUri\"");
						views_Account_LoggedOut.BeginWriteAttribute("href", " href=\"", 714, "\"", 749, 1);
						views_Account_LoggedOut.WriteAttributeValue("", 721, views_Account_LoggedOut.Model.PostLogoutRedirectUri, 721, 28, false);
						views_Account_LoggedOut.EndWriteAttribute();
						views_Account_LoggedOut.WriteLiteral(">here</a> to return to the\r\n                    <span>");
						views_Account_LoggedOut.Write(views_Account_LoggedOut.Model.ClientName);
						views_Account_LoggedOut.WriteLiteral("</span> application.\r\n                </div>\r\n");
					}
					views_Account_LoggedOut.WriteLiteral("\r\n");
					if (views_Account_LoggedOut.Model.SignOutIframeUrl != null)
					{
						views_Account_LoggedOut.WriteLiteral("                <iframe width=\"0\" height=\"0\"");
						views_Account_LoggedOut.BeginWriteAttribute("src", " src=\"", 993, "\"", 1022, 1);
						views_Account_LoggedOut.WriteAttributeValue("", 999, views_Account_LoggedOut.Model.SignOutIframeUrl, 999, 23, false);
						views_Account_LoggedOut.EndWriteAttribute();
						views_Account_LoggedOut.WriteLiteral("></iframe>\r\n");
					}
					views_Account_LoggedOut.WriteLiteral("        </div>\r\n    </div>\r\n</div>\r\n\r\n");
					views_Account_LoggedOut.DefineSection("scripts", new RenderAsyncDelegate(views_Account_LoggedOut.ExecuteAsync_Lambda_10_1));
				}
				catch (Exception ex)
				{
					this.stateMachineState = -2;
					this.taskBuilder.SetException(ex);
					return;
				}
				this.stateMachineState = -2;
				this.taskBuilder.SetResult();
			}

			// Token: 0x06000A6D RID: 2669 RVA: 0x00046CC0 File Offset: 0x00044EC0
			[DebuggerHidden]
			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
			{
				this.taskBuilder.SetStateMachine(stateMachine);
			}

			// Token: 0x04000825 RID: 2085
			public int stateMachineState;

			// Token: 0x04000826 RID: 2086
			public AsyncTaskMethodBuilder taskBuilder;

			// Token: 0x04000827 RID: 2087
			public Views_Account_LoggedOut capturedThis;

			// Token: 0x04000828 RID: 2088
			private TaskAwaiter awaiter_1;
		}
	}
}
